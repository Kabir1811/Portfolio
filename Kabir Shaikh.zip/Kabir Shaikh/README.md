<h2>Portfolio</h1>

This is my portfolio page source code. Feel free to PM me.

I made it using:
  - HTML
  - CSS
  - JAVASCRIPT
  - Boxicons - https://boxicons.com/
  - Scroll reveal - https://scrollrevealjs.org/

You can see the site [here](https://www.safetpojskic.com)
